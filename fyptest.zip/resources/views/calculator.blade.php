@extends('layouts.layout')

@section('title', 'Calculator')

@section('content')

<body>
    <style>
        .output {
            display: flex;
            justify-content: space-evenly;
        }
    </style>

    <div class="container mt-4 mb-5">
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><span style="color:gold">Calculator</span></li>
            </ol>
        </nav>

        <h5 class="mt-4">Current Gold Price (USD/g) ({{$currentGoldPrice_updTime}}):
            <span class="text-warning">{{$currentGoldPrice_USDg}}</span>
        </h5>
        <h5 class="mt-4">
            Current Exchange Rate (MYR/USD) ({{$exchangeRate_updTime}}):
            <span class="text-warning">{{$exchangeRate}}</span>
        </h5>
        <form action="" method="post" class="align-item-center">
            @csrf
            <div class="row justify-content-center mt-4 mb-3">
                <div class="col-sm-3">
                    <h4>Buy date:</h4>
                    <input type="date" class="bg-dark form-control text-white" style="color-scheme: dark;" name="buyDate" value="{{$buyDate}}">
                </div>
                <div class="col-sm-3">
                    <h4>Gold price(USD/g):</h4>
                    <input type="text" class="bg-dark form-control text-white" style="color-scheme: dark;" name="goldPrice" value="{{$goldPrice}}">
                </div>
                <div class="col-sm-3">
                    <h4>Downpayment(USD):</h4>
                    <input type="text" class="bg-dark form-control text-white" style="color-scheme: dark;" name="downpayment_USD" value="{{$downpayment_USD}}">
                </div>
            </div>
            <div class="col-md-12 text-center">
                <button class="btn btn-outline-warning" type="submit">submit</button>
            </div>
        </form>
        <hr>
        @if(Request::isMethod('post'))
        <div class="row">
            <table class="col-6">
                <tr>
                    <td>
                        <h4>Total Holding Gold(g)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$totalHoldingGold}}</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Convert({{$convertPercent}}%)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$convert_USD}}&nbsp;USD &nbsp; {{$convert_MYR}}&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Holding Amt({{100-$convertPercent}}%)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$holdingAmt_USD}}&nbsp;USD &nbsp; {{$holdingAmt_MYR}}&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>GC Amt(g)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$GCAmt}}</h4>
                    </td>
                </tr>
            </table>
            <!-- <div class="output">
            <div class="col-5">
                <h4>Total Holding Gold(g):</h4>
                <h4>Convert({{$convertPercent}}%):</h4>
                <h4>Holding Amt({{100-$convertPercent}}%):</h4>
                <h4>GC Amt(g):</h4>
            </div>
            <div class="col-5">
                <h4 class="text-warning">&nbsp;{{$totalHoldingGold}}</h4>
                <h4 class="text-warning">&nbsp;{{$convert_USD}}&nbsp;USD&nbsp;&nbsp;{{$convert_MYR}}&nbsp;MYR</h4>
                <h4 class="text-warning">&nbsp;{{$holdingAmt_USD}}&nbsp;USD&nbsp;&nbsp;{{$holdingAmt_MYR}}&nbsp;MYR</h4>
                <h4 class="text-warning">&nbsp;{{$GCAmt}}</h4>
            </div>
        </div> -->

            <table class="col-6">
                <tr>
                    <td>
                        <h4>Terminate Date</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$terminateDate}}</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Current Value</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$currentValue_USD}}&nbsp;USD &nbsp; {{$currentValue_MYR}}&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Holding days</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$days}}</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Management Fee /day(3.5%)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$managementFee_day_USD}}&nbsp;USD &nbsp; {{$managementFee_day_MYR}}&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Total management Fee</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$managementFee_total_USD}}&nbsp;USD &nbsp; {{$managementFee_total_MYR}}&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Net CashOut</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$netCashOut_USD}}&nbsp;USD &nbsp; {{$netCashOut_MYR}}&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Profit</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning">{{$profit_USD}}&nbspUSD &nbsp; {{$profit_MYR}}&nbsp;MYR</h4>
                    </td>
                </tr>
            </table>

            <!-- <div class="output">
            <div class="col-5">
                <h4>Terminate Date:</h4>
                <h4>Current Value:</h4>
                <h4>Holding days:</h4>
                <h4>Management Fee /day(3.5%):</h4>
                <h4>Total management Fee:</h4>
                <h4>Net CashOut:</h4>
                <h4>Profit:</h4>
            </div>
            <div class="col-5">
                <h4 class="text-warning">{{$terminateDate}}</h4>
                <h4 class="text-warning">{{$currentValue_USD}} USD &nbsp;&nbsp; {{$currentValue_MYR}} MYR</h4>
                <h4 class="text-warning">{{$days}}</h4>
                <h4 class="text-warning">{{$managementFee_day_USD}} USD &nbsp;&nbsp; {{$managementFee_day_MYR}} MYR</h4>
                <h4 class="text-warning">{{$managementFee_total_USD}} USD &nbsp;&nbsp; {{$managementFee_total_MYR}} MYR</h4>
                <h4 class="text-warning">{{$netCashOut_USD}} USD &nbsp;&nbsp; {{$netCashOut_MYR}} MYR</h4>
                <h4 class="text-warning">{{$profit_USD}} USD &nbsp;&nbsp; {{$profit_MYR}} MYR</h4>
            </div>
        </div> -->
        </div>
        @endif
    </div>

    <script>
        // $(document).ready(function($) {
        //     var count = 10;
        //     var timer = setInterval(function() {
        //         $('#countdown').text(count);
        //         count--;
        //         if (count < 0) {
        //             clearInterval(timer);
        //             // do something when countdown is finished
        //             //alert("view");
        //             $.post('/calculator', {
        //             }, function(data) {
        //                 // handle success response from server
        //             });
        //         }
        //     }, 1000);
        // });
    </script>
</body>
@endsection