<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title')</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- favicon -->
    <link rel="icon" type="image/x-icon" href="{{asset('/images/logo-only.png')}}">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <!-- vite(['resources/sass/app.scss', 'resources/js/app.js']) -->
</head>

<body>
    <style>
        body {
            background-color: #2E3236 !important;
            background-size: cover;
            background-repeat: no-repeat;
            font-family: "Marcellus SC";
            color: #FFFFFF !important;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            min-width: 400px
        }

        #app {
            flex: 1;
        }

        .navbar {
            font-size: 18px;
        }

        a.nav-link {
            padding: 14px;
            border-bottom: 1.5px solid transparent;
            /* color: #ab9002; */
            position: relative;
        }

        a.nav-link::after {
            content: "";
            height: 1px;
            width: 100%;
            position: absolute;
            background-color: gold;
            transform: scaleX(0);
            transition: transform 250ms ease-in-out;
            left: 0;
            bottom: -1px;
        }

        a.nav-link:hover::after {
            transform: scaleX(1);
        }

        .active a.nav-link:hover::after {
            transform: scaleX(0);
        }

        a.nav-link:hover {
            color: gold !important;
            /* border-bottom-color: gold; */
        }

        .active a.nav-link {
            color: gold !important;
            /* border-bottom-color: gold; */
        }

        #navbarSupportedContent ul li {
            width: fit-content;
        }

        .active a.nav-link::before {
            content: "";
            /* height: 0; */
            width: 0;
            border-left: 7px solid transparent;
            border-right: 7px solid transparent;
            border-bottom: 7px solid gold;
            position: absolute;
            left: 50%;
            transform: translate(-7px, 0);
            bottom: 0;
        }

        .breadcrumb {
            padding: 8px 15px;
            margin-bottom: 20px;
            list-style: none;
            background-color: #434651;
            border-radius: 4px;
        }

        /* .breadcrumb-item {
            display: inline-block;
            margin-right: 0.5rem;
        } */

        .breadcrumb-item+.breadcrumb-item::before {
            content: "›";
            vertical-align: middle;
            margin: 0 0.5rem;
            color: #6c757d;
        }

        .breadcrumb-item.active {
            font-weight: 500;
            color: #212529;
        }

        .background-image {
            background-image: url("images/3_2.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            height: 91vh;
            position: relative;
        }

        .footer {
            padding-top: 20px;
            /* position: absolute;
            bottom: 0;
            width: 100%; */
        }
    </style>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="{{ url('/') }}">
                <img src="{{asset('/images/logo.svg')}}" alt="Gold Asset Management Logo" width="300">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item {{ Request::is('/') ? 'active' : '' }}">
                        <a class="nav-link" href="{{ url('/') }}">Home</a>
                    </li>
                    <li class="nav-item {{ Request::is('plan') ? 'active' : '' }}">
                        <a class="nav-link" href="{{ url('/plan') }}">Plan</a>
                    </li>
                    <li class="nav-item {{ Request::is('calculator') ? 'active' : '' }}">
                        <a class="nav-link" href="{{ url('/calculator') }}">Calculator</a>
                    </li>
                    <li class="nav-item {{ Request::is('goldprice') ? 'active' : '' }}">
                        <a class="nav-link" href="{{ url('/goldprice') }}">Gold Price</a>
                    </li>
                    <li class="nav-item {{ Request::is('about') ? 'active' : '' }}">
                        <a class="nav-link" href="{{ url('#about') }}">About Us</a>
                    </li>
                    <li class="nav-item {{ Request::is('contact') ? 'active' : '' }}">
                        <a class="nav-link" href="{{ url('#contact') }}">Contact Us</a>
                    </li>
                </ul>

                <ul class="navbar-nav ms-auto">
                    @auth
                    <li class="nav-item {{ Request::is('profile') ? 'active' : '' }}">
                        <a class="nav-link" href="{{ route('profile') }}">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                            </svg>
                            {{ __('username') }}
                        </a>
                    </li>
                    @else
                    <li class="nav-item {{ Request::is('login') ? 'active' : '' }}">
                        <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                    </li>
                    <li class="nav-item {{ Request::is('register') ? 'active' : '' }}">
                        <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                    </li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>

    <div id="app">
        <!-- <nav class="navbar navbar-expand-md navbar-dark bg-black shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    <img src="{{ asset('img/logo.png') }}" alt="Gold Asset Management Logo" width="150">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item {{ Request::is('/') ? 'active' : '' }}">
                            <a class="nav-link" href="{{ url('/') }}">Home</a>
                        </li>
                        <li class="nav-item {{ Request::is('pricing') ? 'active' : '' }}">
                            <a class="nav-link" href="{{ url('/pricing') }}">Pricing</a>
                        </li>
                        <li class="nav-item {{ Request::is('about') ? 'active' : '' }}">
                            <a class="nav-link" href="{{ url('/about') }}">About Us</a>
                        </li>
                        <li class="nav-item {{ Request::is('contact') ? 'active' : '' }}">
                            <a class="nav-link" href="{{ url('/contact') }}">Contact</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item {{ Request::is('login') ? 'active' : '' }}">
                            <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                        </li>
                        <li class="nav-item {{ Request::is('/register') ? 'active' : '' }}">
                            <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav> -->


        <main>
            @yield('content')
        </main>

    </div>

    <footer class="footer bg-dark">
        <div class="container">
            <p class="text-white">I am footer</p>

        </div>
    </footer>
</body>

</html>