@extends('layouts.layout')

@section('title', 'Gold Price')

@section('content')

<!-- <head>
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head> -->

<body>

    <style>
        .tick {
            color: lime;
        }

        .gold {
            color: gold;
        }
    </style>

    <div class="container mt-4 mb-5">
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><span style="color:gold">Plan</span></li>
            </ol>
        </nav>

        <h3>Subsciption plan & pricing</h3>

        <table class="table table-dark text-center fs-5">
            <thead class="align-middle">
                <tr>
                    <th>Plans</th>
                    <th>
                        <h5>Basic</h5>
                        <h5><span class="gold">$0</span> <span class="text-muted">/month</span></h5>
                        <a href="#" class="btn btn-primary">SELECT</a>
                    </th>
                    <th>
                        <h5>Standard</h5>
                        <h5><span class="gold">$9.99</span> <span class="text-muted">/month</span></h5>
                        <a href="#" class="btn btn-primary">SELECT</a>
                    </th>
                    <th>
                        <h5>Premium</h5>
                        <h5><span class="gold">1.99</span> <span class="text-muted">/month</span></h5>
                        <a href="#" class="btn btn-primary">SELECT</a>
                    </th>
                </tr>
            </thead>
            <tbody class="align-middle">
                <tr>
                    <td>
                        Number of portfolio
                    </td>
                    <td>
                        5
                    </td>
                    <td>
                        50
                    </td>
                    <td>
                        500
                    </td>
                </tr>
                <tr>
                    <td>
                        Number of transactions in each portfolio
                    </td>
                    <td>
                        10
                    </td>
                    <td>
                        100
                    </td>
                    <td>
                        1000
                    </td>
                </tr>
                <tr>
                    <td>
                        Feature A
                    </td>
                    <td class="tick">
                        ✔
                    </td>
                    <td class="tick">
                        ✔
                    </td>
                    <td class="tick">
                        ✔
                    </td>
                </tr>
                <tr>
                    <td>
                        Feature B
                    </td>
                    <td>
                        ❌
                    </td>
                    <td>
                        ❌
                    </td>
                    <td class="tick">
                        ✔
                    </td>
                </tr>
                <tr>
                    <td>
                        Feature C
                    </td>
                    <td>
                        ❌
                    </td>
                    <td class="tick">
                        ✔
                    </td>
                    <td class="tick">
                        ✔
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script> -->
    <script>
       
    </script>
</body>
@endsection