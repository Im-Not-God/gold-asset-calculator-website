@extends('layouts.layout')

@section('title', 'Home')

@section('content')
<style>
    .filter {
        background-color: rgba(0, 0, 0, 0.3);
        height: 100%;
        width: 100%;
        left: 0px;
        position: absolute;
    }
</style>
<div class="background-image">
    <div class="filter"></div>
    <div class="container">

        <div class="py-4" style="position: relative;">
            <div class="text-center" style="padding: 20vh 20px;">
                <h1 style="color:gold; font-weight:bold">Gold Calculator</h1><br><br>
                <p style="color:white" class="fs-4">It was going to rain. The weather forecast didn't say that, but the steel plate in his hip did. He had learned over the years to trust his hip over the weatherman. It was going to rain, so he better get outside and prepare.</p>
            </div>
            <!-- <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">{{ __('Pricing') }}</div>
                        <div class="card-body">
                            <p>Choose the plan that best suits your needs:</p>
                            <ul>
                                <li>Basic - $9.99/month</li>
                                <li>Premium - $19.99/month</li>
                                <li>Gold - $29.99/month</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center mt-4">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">{{ __('About') }}</div>
                        <div class="card-body">
                            <p>We are a team of experienced professionals who specialize in gold asset management. Our goal is to help you make informed decisions and grow your wealth through smart investments.</p>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- <div class="row justify-content-center mt-4">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">{{ __('Contact') }}</div>
                        <div class="card-body">
                            <p>For any inquiries, please contact us at:</p>
                            <ul>
                                <li>Email: info@goldassetmanagement.com</li>
                                <li>Phone: 1-800-GOLD-123</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
    </div>

</div>
<div style="background-color: gold;" id="plan">
    <div class="container py-4 text-center">
        <h1 style="color:black; font-weight:bold">Subscription Plan</h1><br>
        <div class="row justify-content-center align-items-center">
            <div class="col-md-3 mb-1">
                <div class="card bg-dark">
                    <div class="card-body">
                        <h5 class="card-title">Basic</h5>
                        <h5 class="card-title">$0 <span class="text-muted">/month</span></h5>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-1">
                <div class="card bg-dark p-3">
                    <div class="card-body">
                        <h5 class="card-title fs-4">Standard</h5>
                        <h5 class="card-title fs-4">$9.99 <span class="text-muted">/month</span></h5>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-1">
                <div class="card bg-dark">
                    <div class="card-body">
                        <h5 class="card-title">Premium</h5>
                        <h5 class="card-title">$19.99 <span class="text-muted">/month</span></h5>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Begin Gold Price Script - GOLDPRICE.ORG -->
<div style="border: 1px solid #000000; width: 300px; height: auto; font-family: Arial; background-color: #FFFFFF; margin: auto;">
    <div style="margin: 0px auto; width: 100%; height: 24px; text-align: center; padding-top: 0px; font-size: 18px; font-weight: bold; background-color: #000000;"><a style="color: #FFFFFF; background-color: #000000; text-decoration: none;" href="http://goldprice.org" target="_blank"></a></div>
    <div id="gold-price" data-gold_price="USD-o-1d"></div>
    <script type="text/javascript" src="/js/charts-goldprice-org/gold-price.js"></script>
</div>
<!-- End Gold Price Script - GOLDPRICE.ORG -->

@endsection