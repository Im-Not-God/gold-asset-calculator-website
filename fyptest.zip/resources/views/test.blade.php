<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>fypTest</title>

    <style>
        h4{
            color: rgb(200, 26, 26);
        }
        .output {
            display: flex;
            justify-content: space-evenly;
        }
    </style>
</head>
<body>
    <form action="" method="post">
        @csrf
        <h3>Buy date:</h3>
        <input type="date" name="buyDate" value="{{$buyDate}}">
        <br>
        <h3>Gold price(USD/g):</h3>
        <input type="text" name="goldPrice" value="{{$goldPrice}}">
        <br>
        <h3>Downpayment(USD):</h3>
        <input type="text" name="downpayment_USD" value="{{$downpayment_USD}}">
        <br>
        <button type="submit">submit</button>
    </form>
    <hr>
    @if(Request::isMethod('post'))
        <div class="output">
            <div>
                <h3>Total Holding Gold(g):</h3>
                <h4>{{$totalHoldingGold}}</h4>
                <h3>Convert({{$convertPercent}}%):</h3>
                <h4>{{$convert_USD}} USD &nbsp;&nbsp; {{$convert_MYR}} MYR</h4>
                <h3>Holding Amt({{100-$convertPercent}}%):</h3>
                <h4>{{$holdingAmt_USD}} USD &nbsp;&nbsp; {{$holdingAmt_MYR}} MYR</h4>
                <h3>GC Amt(g):</h3>
                <h4>{{$GCAmt}}</h4>
            </div>
            <div>
                <h3>Terminate Date:</h3>
                <h4>{{$terminateDate}}</h4>
                <h3>Current Value:</h3>
                <h4>{{$currentValue_USD}} USD &nbsp;&nbsp; {{$currentValue_MYR}} MYR</h4>
                <h3>Holding days:</h3>
                <h4>{{$days}}</h4>
                <h3>Management Fee /day(3.5%):</h3>
                <h4>{{$managementFee_day_USD}} USD &nbsp;&nbsp; {{$managementFee_day_MYR}} MYR</h4>
                <h3>Total management Fee:</h3>
                <h4>{{$managementFee_total_USD}} USD &nbsp;&nbsp; {{$managementFee_total_MYR}} MYR</h4>
                <h3>Net CashOut:</h3>
                <h4>{{$netCashOut_USD}} USD &nbsp;&nbsp; {{$netCashOut_MYR}} MYR</h4>
                <h3>Profit:</h3>
                <h4>{{$profit_USD}} USD &nbsp;&nbsp; {{$profit_MYR}} MYR</h4>
            </div>
        </div>
        <hr>
        <h3>Current Gold Price (USD/g) ({{$currentGoldPrice_updTime}}):</h3>
        <h4>{{$currentGoldPrice_USDg}}</h4>
    @endif
</body>
</html>