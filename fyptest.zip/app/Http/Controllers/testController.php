<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;

class testController extends Controller
{
    function calc(Request $req)
    {
        if($req->goldPrice ==null){
            return redirect('/calculator');
        }
        $goldPrice = $req->goldPrice;
        $downpayment_USD = $req->downpayment_USD;
        $totalHoldingGold = $downpayment_USD / $goldPrice;
        $convertPercent = 0.91;
        $convert_USD = $downpayment_USD * $convertPercent;
        $holdingAmt = $downpayment_USD - $convert_USD;
        $GCAmt = $convert_USD / $goldPrice;

        $getCurrentGoldPrice = null;
        if(session("getCurrentGoldPrice")){
            $getCurrentGoldPrice = session()->get("getCurrentGoldPrice");
        }else{
            $getCurrentGoldPrice = $this->getGoldPrice();
        }
        // $currentGoldPrice_USDtroyoz = $getCurrentGoldPrice["rates"]["USD"];
        // $currentGoldPrice_USDg = $currentGoldPrice_USDtroyoz / 31.1035;

        //$currentGoldPrice_USDg = $getCurrentGoldPrice["price_gram_24k"];
        $currentGoldPrice_USDg = $getCurrentGoldPrice["items"][0]["xauPrice"] / 31.1035;
        date_default_timezone_set('Asia/Kuala_Lumpur');
        $currentGoldPrice_updTime="";
        if(strlen((string)$getCurrentGoldPrice["ts"]) - strlen((string)time())  > 2){
            $currentGoldPrice_updTime = gmdate("Y-m-d H:i:s", $getCurrentGoldPrice["ts"] / 1000 + date("Z"));
        }else{
            $currentGoldPrice_updTime = gmdate("Y-m-d H:i:s", $getCurrentGoldPrice["ts"] + date("Z"));
        }

        $exchangeRate = null;
        if(session("exchangeRate")){
            $exchangeRate = session()->get("exchangeRate");
        }else{
            $exchangeRate = $this->getExchange();
        }

        $terminateDate = date("Y-m-d");
        $currentValue = $currentGoldPrice_USDg * $totalHoldingGold;
        $days = date_diff(date_create($req->buyDate), date_create($terminateDate))->format("%a");
        $managementFee_day = $convert_USD * 0.035 / 365;
        $managementFee_total = $managementFee_day * $days;
        $netCashOut = $currentValue - $convert_USD - $managementFee_total;
        $profit = $netCashOut - $holdingAmt;
        //$profit = $currentValue - $downpayment_USD - $managementFee_total;

        $exchangeRate_updTime="";
        if(strlen((string)$exchangeRate['timestamp']) - strlen((string)time())  > 2){
            $exchangeRate_updTime = gmdate("Y-m-d H:i:s", $exchangeRate['timestamp'] / 1000 + date("Z"));
        }else{
            $exchangeRate_updTime = gmdate("Y-m-d H:i:s", $exchangeRate['timestamp'] + date("Z"));
        }
        

        return view("calculator", [
            'buyDate' => $req->buyDate,
            'goldPrice' => $goldPrice,
            'downpayment_USD' => $downpayment_USD,
            'totalHoldingGold' => $totalHoldingGold,
            'convertPercent' => $convertPercent * 100,
            'convert_USD' => number_format($convert_USD, 2, '.', ''),
            'convert_MYR' => number_format($convert_USD * $exchangeRate['rates']['MYR'], 2, '.', ''),
            'holdingAmt_USD' => $holdingAmt,
            'holdingAmt_MYR' => number_format($holdingAmt * $exchangeRate['rates']['MYR'], 2, '.', ''),
            'GCAmt' => $GCAmt,
            'currentGoldPrice_USDg' => number_format($currentGoldPrice_USDg, 2, '.', ''),
            'currentGoldPrice_updTime' => $currentGoldPrice_updTime,
            'exchangeRate' => number_format($exchangeRate['rates']['MYR'], 2, '.', ''),
            'exchangeRate_updTime' => $exchangeRate_updTime,


            'terminateDate' => $terminateDate,
            'currentValue_USD' => number_format($currentValue, 2, '.', ''),
            'currentValue_MYR' => number_format($currentValue * $exchangeRate['rates']['MYR'], 2, '.', ''),
            'days' => $days,
            'managementFee_day_USD' => number_format($managementFee_day, 2, '.', ''),
            'managementFee_day_MYR' => number_format($managementFee_day * $exchangeRate['rates']['MYR'], 2, '.', ''),
            'managementFee_total_USD' => number_format($managementFee_total, 2, '.', ''),
            'managementFee_total_MYR' => number_format($managementFee_total * $exchangeRate['rates']['MYR'], 2, '.', ''),
            'netCashOut_USD' => number_format($netCashOut, 2, '.', ''),
            'netCashOut_MYR' => number_format($netCashOut * $exchangeRate['rates']['MYR'], 2, '.', ''),
            'profit_USD' => number_format($profit, 2, '.', ''),
            'profit_MYR' => number_format($profit * $exchangeRate['rates']['MYR'], 2, '.', '')
        ]);
    }

    public function index()
    {
        $getCurrentGoldPrice = $this->getGoldPrice();
        session()->put("getCurrentGoldPrice", $getCurrentGoldPrice);
        $currentGoldPrice_USDg = $getCurrentGoldPrice["items"][0]["xauPrice"] / 31.1035;
        date_default_timezone_set('Asia/Kuala_Lumpur');
        $currentGoldPrice_updTime="";
        if(strlen((string)$getCurrentGoldPrice["ts"]) - strlen((string)time())  > 2){
            $currentGoldPrice_updTime = gmdate("Y-m-d H:i:s", $getCurrentGoldPrice["ts"] / 1000 + date("Z"));
        }else{
            $currentGoldPrice_updTime = gmdate("Y-m-d H:i:s", $getCurrentGoldPrice["ts"] + date("Z"));
        }
        $exchangeRate = $this->getExchange();
        session()->put("exchangeRate", $exchangeRate);

        $exchangeRate_updTime="";
        if(strlen((string)$exchangeRate['timestamp']) - strlen((string)time())  > 2){
            $exchangeRate_updTime = gmdate("Y-m-d H:i:s", $exchangeRate['timestamp'] / 1000 + date("Z"));
        }else{
            $exchangeRate_updTime = gmdate("Y-m-d H:i:s", $exchangeRate['timestamp'] + date("Z"));
        }
        return view('calculator', [
            'buyDate' => null,
            'goldPrice' => null,
            'downpayment_USD' => null,
            'currentGoldPrice_USDg' => number_format($currentGoldPrice_USDg, 2, '.', ''),
            'currentGoldPrice_updTime' => $currentGoldPrice_updTime,
            'exchangeRate' => number_format($exchangeRate['rates']['MYR'], 2, '.', ''),
            'exchangeRate_updTime' => $exchangeRate_updTime,
        ]);
    }

    protected function getGoldPrice($str = "USD")
    {
        $client = new Client();
        //free 100/mon 1hrs upd --metalpriceapi.com
        //$response = $client->get('https://api.metalpriceapi.com/v1/latest?api_key=bdeacda07a5f20d95f4760815d6dd69a&base=XAU&currencies=USD',['verify' => false]);
        //free 500/mon 2sec upd --goldapi.io
        //$response = $client->get('https://www.goldapi.io/api/XAU/'.$str, ['verify' => false, 'headers' => ['x-access-token' => 'goldapi-18rvhwrlefik3sb-io']]);
        $response = $client->get('https://data-asg.goldprice.org/dbXRates/'.$str, ['verify' => false]);
        if ($response->getStatusCode() == 200) { // 200 OK
            $response_data = $response->getBody()->getContents();
            $json = json_decode($response_data, true);
            return $json;
        }
    }
    //1 USD to MYR
    protected function getExchange($str = "MYR")
    {
        // $client = new Client();
        // $response = $client->get('https://v6.exchangerate-api.com/v6/a8a5ef7aaa7b72d11a41fb7f/latest/USD', ['verify' => false]);
        // if ($response->getStatusCode() == 200) { // 200 OK
        //     $response_data = $response->getBody()->getContents();
        //     $json = json_decode($response_data, true);
        //     return $json["conversion_rates"][$str];
        // }
        $client = new Client();
        $response = $client->get("https://api.apilayer.com/exchangerates_data/latest?symbols=$str&base=USD", ['verify' => false, 'headers' => ["apikey" => "W2HREI6uelhoxk43D8TkdRGeeXXWR92j"]]);
        if ($response->getStatusCode() == 200) { // 200 OK
            $response_data = $response->getBody()->getContents();
            $json = json_decode($response_data, true);
            return $json;
        }
    }
}
