<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>fypTest</title>

    <style>
        h4{
            color: rgb(200, 26, 26);
        }
        .output {
            display: flex;
            justify-content: space-evenly;
        }
    </style>
</head>
<body>
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <h3>Buy date:</h3>
        <input type="date" name="buyDate" value="<?php echo e($buyDate); ?>">
        <br>
        <h3>Gold price(USD/g):</h3>
        <input type="text" name="goldPrice" value="<?php echo e($goldPrice); ?>">
        <br>
        <h3>Downpayment(USD):</h3>
        <input type="text" name="downpayment_USD" value="<?php echo e($downpayment_USD); ?>">
        <br>
        <button type="submit">submit</button>
    </form>
    <hr>
    <?php if(Request::isMethod('post')): ?>
        <div class="output">
            <div>
                <h3>Total Holding Gold(g):</h3>
                <h4><?php echo e($totalHoldingGold); ?></h4>
                <h3>Convert(<?php echo e($convertPercent); ?>%):</h3>
                <h4><?php echo e($convert_USD); ?> USD &nbsp;&nbsp; <?php echo e($convert_MYR); ?> MYR</h4>
                <h3>Holding Amt(<?php echo e(100-$convertPercent); ?>%):</h3>
                <h4><?php echo e($holdingAmt_USD); ?> USD &nbsp;&nbsp; <?php echo e($holdingAmt_MYR); ?> MYR</h4>
                <h3>GC Amt(g):</h3>
                <h4><?php echo e($GCAmt); ?></h4>
            </div>
            <div>
                <h3>Terminate Date:</h3>
                <h4><?php echo e($terminateDate); ?></h4>
                <h3>Current Value:</h3>
                <h4><?php echo e($currentValue_USD); ?> USD &nbsp;&nbsp; <?php echo e($currentValue_MYR); ?> MYR</h4>
                <h3>Holding days:</h3>
                <h4><?php echo e($days); ?></h4>
                <h3>Management Fee /day(3.5%):</h3>
                <h4><?php echo e($managementFee_day_USD); ?> USD &nbsp;&nbsp; <?php echo e($managementFee_day_MYR); ?> MYR</h4>
                <h3>Total management Fee:</h3>
                <h4><?php echo e($managementFee_total_USD); ?> USD &nbsp;&nbsp; <?php echo e($managementFee_total_MYR); ?> MYR</h4>
                <h3>Net CashOut:</h3>
                <h4><?php echo e($netCashOut_USD); ?> USD &nbsp;&nbsp; <?php echo e($netCashOut_MYR); ?> MYR</h4>
                <h3>Profit:</h3>
                <h4><?php echo e($profit_USD); ?> USD &nbsp;&nbsp; <?php echo e($profit_MYR); ?> MYR</h4>
            </div>
        </div>
        <hr>
        <h3>Current Gold Price (USD/g) (<?php echo e($currentGoldPrice_updTime); ?>):</h3>
        <h4><?php echo e($currentGoldPrice_USDg); ?></h4>
    <?php endif; ?>
</body>
</html><?php /**PATH D:\laravel\fyptest\resources\views/test.blade.php ENDPATH**/ ?>