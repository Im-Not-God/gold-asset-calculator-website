

<?php $__env->startSection('title', 'Calculator'); ?>

<?php $__env->startSection('content'); ?>

<body>
    <style>
        .output {
            display: flex;
            justify-content: space-evenly;
        }
    </style>

    <div class="container mt-4 mb-5">
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><span style="color:gold">Calculator</span></li>
            </ol>
        </nav>

        <h5 class="mt-4">Current Gold Price (USD/g) (<?php echo e($currentGoldPrice_updTime); ?>):
            <span class="text-warning"><?php echo e($currentGoldPrice_USDg); ?></span>
        </h5>
        <h5 class="mt-4">
            Current Exchange Rate (MYR/USD) (<?php echo e($exchangeRate_updTime); ?>):
            <span class="text-warning"><?php echo e($exchangeRate); ?></span>
        </h5>
        <form action="" method="post" class="align-item-center">
            <?php echo csrf_field(); ?>
            <div class="row justify-content-center mt-4 mb-3">
                <div class="col-sm-3">
                    <h4>Buy date:</h4>
                    <input type="date" class="bg-dark form-control text-white" style="color-scheme: dark;" name="buyDate" value="<?php echo e($buyDate); ?>">
                </div>
                <div class="col-sm-3">
                    <h4>Gold price(USD/g):</h4>
                    <input type="text" class="bg-dark form-control text-white" style="color-scheme: dark;" name="goldPrice" value="<?php echo e($goldPrice); ?>">
                </div>
                <div class="col-sm-3">
                    <h4>Downpayment(USD):</h4>
                    <input type="text" class="bg-dark form-control text-white" style="color-scheme: dark;" name="downpayment_USD" value="<?php echo e($downpayment_USD); ?>">
                </div>
            </div>
            <div class="col-md-12 text-center">
                <button class="btn btn-outline-warning" type="submit">submit</button>
            </div>
        </form>
        <hr>
        <?php if(Request::isMethod('post')): ?>
        <div class="row">
            <table class="col-6">
                <tr>
                    <td>
                        <h4>Total Holding Gold(g)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($totalHoldingGold); ?></h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Convert(<?php echo e($convertPercent); ?>%)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($convert_USD); ?>&nbsp;USD &nbsp; <?php echo e($convert_MYR); ?>&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Holding Amt(<?php echo e(100-$convertPercent); ?>%)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($holdingAmt_USD); ?>&nbsp;USD &nbsp; <?php echo e($holdingAmt_MYR); ?>&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>GC Amt(g)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($GCAmt); ?></h4>
                    </td>
                </tr>
            </table>
            <!-- <div class="output">
            <div class="col-5">
                <h4>Total Holding Gold(g):</h4>
                <h4>Convert(<?php echo e($convertPercent); ?>%):</h4>
                <h4>Holding Amt(<?php echo e(100-$convertPercent); ?>%):</h4>
                <h4>GC Amt(g):</h4>
            </div>
            <div class="col-5">
                <h4 class="text-warning">&nbsp;<?php echo e($totalHoldingGold); ?></h4>
                <h4 class="text-warning">&nbsp;<?php echo e($convert_USD); ?>&nbsp;USD&nbsp;&nbsp;<?php echo e($convert_MYR); ?>&nbsp;MYR</h4>
                <h4 class="text-warning">&nbsp;<?php echo e($holdingAmt_USD); ?>&nbsp;USD&nbsp;&nbsp;<?php echo e($holdingAmt_MYR); ?>&nbsp;MYR</h4>
                <h4 class="text-warning">&nbsp;<?php echo e($GCAmt); ?></h4>
            </div>
        </div> -->

            <table class="col-6">
                <tr>
                    <td>
                        <h4>Terminate Date</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($terminateDate); ?></h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Current Value</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($currentValue_USD); ?>&nbsp;USD &nbsp; <?php echo e($currentValue_MYR); ?>&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Holding days</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($days); ?></h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Management Fee /day(3.5%)</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($managementFee_day_USD); ?>&nbsp;USD &nbsp; <?php echo e($managementFee_day_MYR); ?>&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Total management Fee</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($managementFee_total_USD); ?>&nbsp;USD &nbsp; <?php echo e($managementFee_total_MYR); ?>&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Net CashOut</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($netCashOut_USD); ?>&nbsp;USD &nbsp; <?php echo e($netCashOut_MYR); ?>&nbsp;MYR</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Profit</h4>
                    </td>
                    <td>
                        <h4>&emsp;:&nbsp;</h4>
                    </td>
                    <td>
                        <h4 class="text-warning"><?php echo e($profit_USD); ?>&nbspUSD &nbsp; <?php echo e($profit_MYR); ?>&nbsp;MYR</h4>
                    </td>
                </tr>
            </table>

            <!-- <div class="output">
            <div class="col-5">
                <h4>Terminate Date:</h4>
                <h4>Current Value:</h4>
                <h4>Holding days:</h4>
                <h4>Management Fee /day(3.5%):</h4>
                <h4>Total management Fee:</h4>
                <h4>Net CashOut:</h4>
                <h4>Profit:</h4>
            </div>
            <div class="col-5">
                <h4 class="text-warning"><?php echo e($terminateDate); ?></h4>
                <h4 class="text-warning"><?php echo e($currentValue_USD); ?> USD &nbsp;&nbsp; <?php echo e($currentValue_MYR); ?> MYR</h4>
                <h4 class="text-warning"><?php echo e($days); ?></h4>
                <h4 class="text-warning"><?php echo e($managementFee_day_USD); ?> USD &nbsp;&nbsp; <?php echo e($managementFee_day_MYR); ?> MYR</h4>
                <h4 class="text-warning"><?php echo e($managementFee_total_USD); ?> USD &nbsp;&nbsp; <?php echo e($managementFee_total_MYR); ?> MYR</h4>
                <h4 class="text-warning"><?php echo e($netCashOut_USD); ?> USD &nbsp;&nbsp; <?php echo e($netCashOut_MYR); ?> MYR</h4>
                <h4 class="text-warning"><?php echo e($profit_USD); ?> USD &nbsp;&nbsp; <?php echo e($profit_MYR); ?> MYR</h4>
            </div>
        </div> -->
        </div>
        <?php endif; ?>
    </div>

    <script>
        // $(document).ready(function($) {
        //     var count = 10;
        //     var timer = setInterval(function() {
        //         $('#countdown').text(count);
        //         count--;
        //         if (count < 0) {
        //             clearInterval(timer);
        //             // do something when countdown is finished
        //             //alert("view");
        //             $.post('/calculator', {
        //             }, function(data) {
        //                 // handle success response from server
        //             });
        //         }
        //     }, 1000);
        // });
    </script>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\fyptest\resources\views/calculator.blade.php ENDPATH**/ ?>