

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>

<head>
    <title>Transaction</title>

    <style>
        thead {
            border-bottom: 1px solid white;
        }

        th,
        td,
        h3 {
            text-align: center;
        }
    </style>

</head>

<body>
    <div class="container mt-4">

        <h3>Portfolio List</h3>
        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>No. of transactions</th>
                    <th>Profit/Loss (USD)</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr class=''>
                    <td>2022-05-04</td>
                    <td>12</td>
                    <td style="color: lime">7.8 ↑</td>
                    <td><button type="button" name="role" value="author" class="btn btn-danger">Delete</button></td>
                </tr>
                <tr class=''>
                    <td>2022-05-19</td>
                    <td>7</td>
                    <td style="color: red">12.5 ↓</td>
                    <td><button type="button" name="role" value="author" class="btn btn-danger">Delete</button></td>
                </tr>
                <tr class=''>
                    <td>2022-05-30</td>
                    <td>9</td>
                    <td style="color: lime">9.6 ↑</td>
                    <td><button type="button" name="role" value="author" class="btn btn-danger">Delete</button></td>
                </tr>
            </tbody>
        </table>

        <button type="button" name="role" value="author" class="btn btn-warning">Add</button>

    </div>

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script> -->
    <script>
        // $(document).ready(function($) {
        //   $(".clickable-row").click(function() {
        //     window.location.href = $(this).data("href");
        //   });
        // });
    </script>
</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\fyptest\resources\views/portfolio.blade.php ENDPATH**/ ?>