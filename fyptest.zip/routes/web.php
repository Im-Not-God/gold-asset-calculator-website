<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\testController;
use App\Http\Controllers\GoldPriceController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('homeTest');
});

Route::get('/test', function () {
    return view('test', [
        'buyDate' => null,
        'goldPrice' => null,
        'downpayment_USD' => null
    ]);
});

Route::post("/test", [testController::class, 'calc']);


Route::get('/api', [testController::class, 'getGoldPrice']);
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/calculator', [testController::class, 'index']);

Route::view('/transaction','transaction');
Route::post("/calculator", [testController::class, 'calc']);

Route::view('/goldprice','goldprice');
Route::get('/goldprice_qm',[GoldPriceController::class, 'index']);

Route::view('/plan','plan');

Route::view('/blank','layouts.layout');

Route::view('/portfolio','portfolio');

